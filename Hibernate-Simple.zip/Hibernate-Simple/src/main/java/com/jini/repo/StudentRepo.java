package com.jini.repo;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

import com.jini.entity.Student;

public class StudentRepo {

	private static SessionFactory sessionFactory = new Configuration().configure(" hibernateExm.cfg.xml").buildSessionFactory();

	public static void main(String[] args) {
		StudentRepo instance = new StudentRepo();
		instance.insertStudent();
		instance.loadStudent();
	}

	private void loadStudent() {
		Session session = sessionFactory.openSession();
		session.beginTransaction();
		Student student = (Student) session.get(Student.class, 1);
		System.out.println(student);
	}
	

	private void insertStudent() {

		Student student1 = new Student("Megha Ma'am", "Indian", "jini.com");
		Student student2 = new Student("Sharma G", "Jini", "sanatanii.com");

		Session session = sessionFactory.openSession();
		session.beginTransaction();
		session.save(student1);
		session.save(student2);
		session.getTransaction().commit();
		session.close();
	}
}
